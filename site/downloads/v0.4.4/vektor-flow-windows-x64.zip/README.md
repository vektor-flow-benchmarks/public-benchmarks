# Vektor Flow

Vektor Flow (VKF) is an experimental compiled language for vector mathematics
and visual programs. A function written for one value can also apply through
vectors and nested vectors.

```vkf static
square(value:int) -> int: value * value
:: square([1, 2, 3])
```

[Try VKF in your browser](https://vektorflow.org/guide.html) ·
[Install VKF](INSTALL.md) ·
[Language reference](docs/language-guide.md) ·
[Benchmarks](docs/site/performance.md)

Experimental software: APIs and diagnostics can change. Do not run untrusted
native VKF programs.
