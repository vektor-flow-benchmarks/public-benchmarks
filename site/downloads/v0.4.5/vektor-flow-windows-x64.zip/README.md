# [Vektor Flow](https://vektorflow.org/)

Vektor Flow (VKF) is a statically typed, expression-oriented compiled language
with immutable-by-default values, value-producing lexical scopes, type and shape
inference, recursive vector lifting and named-index broadcasting.

Explicit scoped mutation, demand-backed lazy evaluation and proof-gated
automatic parallelization keep source deterministic. VKF is best suited to
numerical computing, data pipelines, simulations, symbolic math and visual
programs.

- [Guide](https://vektorflow.org/guide.html) — the language model, compiler
  path, execution rules and supported targets.
- [Syntax](docs/language-guide.md) — exact rules for values, types, scopes,
  vector calls, control flow, operators and modules.
- [Std lib](docs/standard-library.md) — imports and runnable examples for math,
  data, I/O, linear algebra, physics, symbolic work and interactive UI views.
- [Performance](docs/site/performance.md) — the five native tests on three
  operating systems, browser WebAssembly, linear algebra and symbolic results.
- [Download](INSTALL.md) — native and WebAssembly compilers, checksums,
  installation and command-line use.
